import { Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <div style={{ background: '#222', padding: '10px', color: 'white' }}>
      <Link to="/" style={{ margin: '10px', color: 'white' }}>Home</Link> |
      <Link to="/product" style={{ margin: '10px', color: 'white' }}>Product</Link> |
      <Link to="/cart" style={{ margin: '10px', color: 'white' }}>Cart</Link> |
      <Link to="/login" style={{ margin: '10px', color: 'white' }}>Login</Link>
    </div>
  );
}
