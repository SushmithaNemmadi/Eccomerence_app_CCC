
function CartComponent({count}) 
{

return(
<p style={{color:"red"}}>count:{count}</p>

);
}
export default CartComponent;