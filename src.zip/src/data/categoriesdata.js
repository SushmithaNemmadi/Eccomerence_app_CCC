import React from 'react';
import products from '../data/productData'; // adjust path as needed

const CategoriesPage = ({ setSelectedCategory = () => {} }) => {
  const handleCategoryClick = (category) => {
    setSelectedCategory(category);
  };

  return (
    <div>
      <h1>Select a Category</h1>
      <ul>
        {Object.keys(products).map((category) => (
          <li key={category}>
            <button onClick={() => handleCategoryClick(category)}>
              {category}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default CategoriesPage;
