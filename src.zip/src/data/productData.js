const products = {
  "women-footwear": [
    { id: 1, name: "Heels", price: 50 },
    { id: 2, name: "Sandals", price: 30 }
  ],
  "electronics": [
    { id: 3, name: "Laptop", price: 1000 },
    { id: 4, name: "Headphones", price: 100 }
  ],
  "mobile": [
    { id: 5, name: "iPhone", price: 1200 },
    { id: 6, name: "Samsung Galaxy", price: 900 }
  ]
};

export default products;

