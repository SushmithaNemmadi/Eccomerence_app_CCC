import React from 'react';

export default function ProductPage() {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h2>Welcome to the Product Page</h2>
    </div>
  );
}
