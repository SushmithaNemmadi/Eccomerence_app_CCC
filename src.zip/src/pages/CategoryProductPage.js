import React from "react";
import { useParams } from "react-router-dom";
import products from "../data/productData";

const CategoryProductPage = () => {
  const { category } = useParams();
  const categoryProducts = products[category] || [];

  return (
    <div style={{ padding: "20px" }}>
      <h2 style={{ textAlign: "center" }}>
        Category: {category}
      </h2>
      <p style={{ textAlign: "center" }}>URL param: {category}</p>
      <hr />
      {categoryProducts.map(product => (
        <div key={product.id} style={{
          border: "1px solid #ccc",
          padding: "15px",
          margin: "15px 0",
          textAlign: "center"
        }}>
          <h3>{product.name}</h3>
          <img
            src={product.image}
            alt={product.name}
            style={{ width: "150px", height: "150px", objectFit: "cover" }}
          />
          <p>{product.description}</p>
          <p><strong>Price:</strong> ₹{product.price}</p>
          <button>View</button>
        </div>
      ))}
      {categoryProducts.length === 0 && <p>No products found.</p>}
    </div>
  );
};

export default CategoryProductPage;
