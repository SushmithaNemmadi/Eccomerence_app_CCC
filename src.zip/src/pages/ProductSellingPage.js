import React from 'react';
import axios from 'axios';

const ProductCard = ({ productId }) => {
  const handleAddToCart = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.post(
        'http://localhost:5000/addToCart',
        { productId },  // use dynamic productId
        { headers: { Authorization: `Bearer ${token}` } }
      );
      console.log('Added to cart:', res.data.message);
    } catch (err) {
      console.error('Error adding to cart:', err.response?.data?.message || err.message);
    }
  };

  return (
    <div>
      {/* Product details here */}
      <button onClick={handleAddToCart}>Add to Cart</button>
    </div>
  );
};

export default ProductCard;
