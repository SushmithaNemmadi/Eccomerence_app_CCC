import React from 'react';

export default function CartPage() {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h2>Your Cart</h2>
    </div>
  );
}
