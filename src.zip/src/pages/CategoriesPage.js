import React from 'react';
import products from '../data/productData';

const categoryImages = {
  'women-footwear': 'https://example.com/sandals.jpg',
  'electronics': 'https://example.com/smartphone.jpg',
  'mobile': 'https://example.com/mobile.jpg',
};

const CategoriesPage = ({ setSelectedCategory = () => {} }) => {
  const handleCategoryClick = (category) => {
    setSelectedCategory(category);
  };

  return (
    <div style={{ padding: '20px', textAlign: 'center' }}>
      <h2>Categories Page:</h2>
      <div style={{
        display: 'flex',
        justifyContent: 'center',
        gap: '50px',
        marginTop: '30px',
        flexWrap: 'wrap'
      }}>
        {Object.keys(products).map((category) => (
          <div key={category} style={{ textAlign: 'center' }}>
            <img
              src={categoryImages[category]}
              alt={category}
              style={{
                width: '100px',
                height: '100px',
                borderRadius: '50%',
                border: '2px solid gray',
                objectFit: 'cover'
              }}
            />
            <br />
            <button
              onClick={() => handleCategoryClick(category)}
              style={{
                backgroundColor: '#222',
                color: '#fff',
                padding: '8px 16px',
                marginTop: '10px',
                border: 'none',
                borderRadius: '8px',
                fontWeight: 'bold',
              }}
            >
              {category.charAt(0).toUpperCase() + category.slice(1).replace('-', ' ')}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CategoriesPage;
