import React from 'react';

export default function HomePage() {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h2>Welcome to the Home Page</h2>
    </div>
  );
}
